# Yonsei College of Medicine Faculty Crawler (Updated)

연세대학교 의과대학 교수 명단과 기본 정보(영문명, 이메일, 전화번호, 연구실 등)를 수집하는 Selenium 기반 크롤러입니다.

## 이번 업데이트 포함 사항

- `argparse` 실행 옵션 추가
- `collected_at` 수집 시각 저장
- CSV + XLSX 저장
- SQLite 저장
- 재실행 시 기존 `detail_url` 기준 건너뛰기 (`--resume true`)
- 상세 페이지 재시도 로직
- 이메일/전화번호 데이터 정규화
- 요약 통계 JSON 생성

## 폴더 구조

```text
yonsei-med-faculty-crawler-updated/
├─ crawler/
├─ output/
├─ logs/
├─ run.py
├─ requirements.txt
└─ README.md
```

## 설치

```bash
pip install -r requirements.txt
```

## 실행 예시

기본 실행:

```bash
python run.py
```

브라우저 표시 모드:

```bash
python run.py --headless false
```

출력 경로 지정:

```bash
python run.py --csv output/custom.csv --xlsx output/custom.xlsx --db output/custom.db
```

재실행 시 기존 상세 URL 건너뛰기:

```bash
python run.py --resume true
```

테스트용으로 앞의 3개 학과만 실행:

```bash
python run.py --limit-departments 3
```

## 결과 파일

실행 후 아래 파일이 생성됩니다.

- `output/yonsei_medicine_faculty.db`
- `output/yonsei_medicine_faculty.csv`
- `output/yonsei_medicine_faculty.xlsx`
- `output/yonsei_medicine_faculty.summary.json`
- `logs/crawler.log`

## 수집 항목

- college_ko
- college_en
- department_ko
- department_en
- campus
- name_ko
- name_en
- title_ko
- email
- phone
- office
- detail_url
- source_department_url
- collected_at

## SQLite 예시

```sql
SELECT name_ko, name_en, department_ko, email, phone, collected_at
FROM faculty
ORDER BY department_ko, name_ko;
```

## 참고

- Chrome 브라우저가 설치되어 있어야 합니다.
- 처음 실행 시 드라이버 다운로드가 필요합니다.
- 사이트 구조가 바뀌면 파싱 로직 수정이 필요할 수 있습니다.
- 일부 교수 페이지에는 전화번호 또는 이메일이 비어 있을 수 있습니다.
