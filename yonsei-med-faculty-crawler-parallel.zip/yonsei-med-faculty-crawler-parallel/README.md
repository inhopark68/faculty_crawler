# Yonsei College of Medicine Faculty Crawler (Parallel)

연세대학교 의과대학 교수 명단과 기본 정보(영문명, 이메일, 전화번호, 연구실 등)를 수집하는 Selenium 기반 병렬 크롤러입니다.

## 포함 기능

- 병렬 처리 (`ThreadPoolExecutor`)
- `argparse` 실행 옵션
- `collected_at` 수집 시각 저장
- CSV + XLSX 저장
- SQLite 저장
- 재실행 시 기존 `detail_url` 기준 건너뛰기 (`--resume true`)
- 상세 페이지 재시도 로직
- 이메일/전화번호 데이터 정규화
- 요약 통계 JSON 생성

## 설치

```bash
pip install -r requirements.txt
```

## 실행 예시

기본 실행:

```bash
python run.py
```

브라우저 표시 모드:

```bash
python run.py --headless false
```

병렬 워커 수 지정:

```bash
python run.py --workers 6
```

출력 경로 지정:

```bash
python run.py --csv output/custom.csv --xlsx output/custom.xlsx --db output/custom.db
```

기존 상세 URL 건너뛰기:

```bash
python run.py --resume true
```

앞의 3개 학과만 테스트:

```bash
python run.py --limit-departments 3
```

## 결과 파일

- `output/yonsei_medicine_faculty.db`
- `output/yonsei_medicine_faculty.csv`
- `output/yonsei_medicine_faculty.xlsx`
- `output/yonsei_medicine_faculty.summary.json`
- `logs/crawler.log`

## 주의

- Chrome 브라우저가 설치되어 있어야 합니다.
- 병렬 수를 너무 크게 잡으면 PC 자원을 많이 사용합니다. 보통 `4~6` 정도가 무난합니다.
- 사이트 구조가 바뀌면 파싱 로직 수정이 필요할 수 있습니다.
